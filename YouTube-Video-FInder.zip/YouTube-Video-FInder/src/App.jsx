import React, { useState } from 'react';

const API_KEY = 'AIzaSyC21oRlWnNmA3MCu799mhMdxnYoxby-Lo4';
const MAX_RESULTS = 50;
const MAX_PAGES = 10;

export default function App() {
  const [videos, setVideos] = useState([]);
  const [loading, setLoading] = useState(false);
  const [query, setQuery] = useState('free ai tools');
  const [minViews, setMinViews] = useState(1000);
  const [maxDuration, setMaxDuration] = useState(1200);
  const [maxSubs, setMaxSubs] = useState(9999999);
  const [publishWithinDays, setPublishWithinDays] = useState(90);
  const [blacklist, setBlacklist] = useState('');
  const [excludeShorts, setExcludeShorts] = useState(true);
  const [debugStats, setDebugStats] = useState({ total: 0, filtered: 0, passed: 0 });

  const parseISO8601Duration = (d) => {
    const match = d.match(/PT(?:(\d+)H)?(?:(\d+)M)?(?:(\d+)S)?/);
    const h = parseInt(match?.[1] || '0'),
      m = parseInt(match?.[2] || '0'),
      s = parseInt(match?.[3] || '0');
    return h * 3600 + m * 60 + s;
  };

  const formatDuration = (sec) => `${Math.floor(sec / 60)}m ${sec % 60}s`;

  const fetchVideos = async () => {
    setLoading(true);
    setVideos([]);
    setDebugStats({ total: 0, filtered: 0, passed: 0 });

    const publishedAfter = new Date(Date.now() - publishWithinDays * 86400000).toISOString();
    const bannedKeywords = blacklist.toLowerCase().split(',').map(k => k.trim()).filter(Boolean);

    let nextPageToken = '';
    let allVideoIds = [];

    try {
      for (let i = 0; i < MAX_PAGES; i++) {
        const searchUrl = `https://www.googleapis.com/youtube/v3/search?key=${API_KEY}&q=${encodeURIComponent(query)}&part=snippet&type=video&maxResults=${MAX_RESULTS}&publishedAfter=${publishedAfter}&pageToken=${nextPageToken}`;
        const searchRes = await fetch(searchUrl);
        const searchData = await searchRes.json();
        const ids = searchData.items?.map(item => item.id.videoId).filter(Boolean);
        if (ids.length === 0) break;
        allVideoIds.push(...ids);
        nextPageToken = searchData.nextPageToken;
        if (!nextPageToken) break;
      }

      const chunks = [];
      for (let i = 0; i < allVideoIds.length; i += 50) {
        chunks.push(allVideoIds.slice(i, i + 50));
      }

      let filteredOut = 0;
      const fullVideos = [];

      for (const chunk of chunks) {
        const detailsUrl = `https://www.googleapis.com/youtube/v3/videos?key=${API_KEY}&id=${chunk.join(',')}&part=snippet,statistics,contentDetails`;
        const detailsRes = await fetch(detailsUrl);
        const detailsData = await detailsRes.json();

        const filtered = detailsData.items.filter(video => {
          const views = parseInt(video.statistics.viewCount || '0');
          const duration = parseISO8601Duration(video.contentDetails.duration);
          const title = video.snippet.title.toLowerCase();
          const isBanned = bannedKeywords.some(word => title.includes(word));
          const isShort = duration < 60 || title.includes('#shorts');

          const passed = (
            views >= minViews &&
            duration <= maxDuration &&
            (!excludeShorts || !isShort) &&
            !isBanned
          );

          if (!passed) filteredOut++;
          return passed;
        });

        const enriched = await Promise.all(
          filtered.map(async (video) => {
            const channelId = video.snippet.channelId;
            const channelRes = await fetch(
              `https://www.googleapis.com/youtube/v3/channels?key=${API_KEY}&id=${channelId}&part=statistics`
            );
            const channelData = await channelRes.json();
            const subs = parseInt(channelData.items?.[0]?.statistics?.subscriberCount || '0');
            if (subs > maxSubs) {
              filteredOut++;
              return null;
            }
            return {
              title: video.snippet.title,
              url: `https://www.youtube.com/watch?v=${video.id}`,
              channel: video.snippet.channelTitle,
              views: parseInt(video.statistics.viewCount),
              published: video.snippet.publishedAt,
              duration: formatDuration(parseISO8601Duration(video.contentDetails.duration)),
              subs,
              thumbnail: video.snippet.thumbnails.medium.url,
            };
          })
        );

        fullVideos.push(...enriched.filter(Boolean));
      }

      setDebugStats({ total: allVideoIds.length, filtered: filteredOut, passed: fullVideos.length });
      setVideos(fullVideos);
    } catch (err) {
      console.error('Failed to fetch videos:', err);
    }

    setLoading(false);
  };

  return (
    <div style={{ fontFamily: 'sans-serif', background: '#111', color: '#fff', minHeight: '100vh', paddingBottom: '4rem' }}>
      <header style={{ padding: '2rem' }}>
        <h1 style={{ fontSize: '2rem', marginBottom: '0.5rem' }}>🎥 YouTube Video Finder</h1>
        <p style={{ color: '#ccc' }}>Search YouTube videos with filters — now with shorts filtering + debug view.</p>
      </header>

      <section style={{ background: '#1f1f1f', padding: '2rem', margin: '1rem auto', maxWidth: '900px', borderRadius: '10px' }}>
        <h2 style={{ marginBottom: '1rem' }}>🔍 Search Filters</h2>
        <form onSubmit={(e) => { e.preventDefault(); fetchVideos(); }}>
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(200px, 1fr))', gap: '1rem', marginBottom: '1.5rem' }}>
            <div><label style={labelStyle}>Search Topic</label><input value={query} onChange={e => setQuery(e.target.value)} placeholder="e.g. AI tools" style={inputStyle} /></div>
            <div><label style={labelStyle}>Min Views</label><input type="number" value={minViews} onChange={e => setMinViews(Number(e.target.value))} style={inputStyle} /></div>
            <div><label style={labelStyle}>Max Duration (seconds)</label><input type="number" value={maxDuration} onChange={e => setMaxDuration(Number(e.target.value))} style={inputStyle} /></div>
            <div><label style={labelStyle}>Max Subscribers</label><input type="number" value={maxSubs} onChange={e => setMaxSubs(Number(e.target.value))} style={inputStyle} /></div>
            <div><label style={labelStyle}>Published Within (days)</label><input type="number" value={publishWithinDays} onChange={e => setPublishWithinDays(Number(e.target.value))} style={inputStyle} /></div>
            <div><label style={labelStyle}>Exclude Keywords</label><input value={blacklist} onChange={e => setBlacklist(e.target.value)} placeholder="e.g. whatsapp, gaming" style={inputStyle} /></div>
            <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
              <input type="checkbox" checked={excludeShorts} onChange={(e) => setExcludeShorts(e.target.checked)} />
              <label style={labelStyle}>Exclude Shorts</label>
            </div>
          </div>
          <button type="submit" disabled={loading} style={buttonStyle}>{loading ? "Searching..." : "Find Videos"}</button>
        </form>
      </section>

      <section style={{ padding: '1rem 2rem', maxWidth: '900px', margin: '0 auto', color: '#aaa', fontSize: '0.9rem' }}>
        <p>🔎 Total videos scanned: {debugStats.total} | Filtered out: {debugStats.filtered} | ✅ Final results: {debugStats.passed}</p>
        {debugStats.passed === 0 && !loading && <p style={{ color: 'orange' }}>⚠️ Try loosening your filters to see more results.</p>}
      </section>

      <section style={{ padding: '2rem', maxWidth: '1200px', margin: '0 auto' }}>
        {videos.length === 0 && !loading && <p>No videos found. Try adjusting your filters.</p>}
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(300px, 1fr))', gap: '1.5rem' }}>
          {videos.map((v, i) => (
            <div key={i} style={{ background: '#fff', color: '#111', borderRadius: '10px', overflow: 'hidden', boxShadow: '0 2px 10px rgba(0,0,0,0.2)' }}>
              <a href={v.url} target="_blank" rel="noopener noreferrer">
                <img src={v.thumbnail} alt={v.title} style={{ width: '100%' }} />
              </a>
              <div style={{ padding: '1rem' }}>
                <a href={v.url} target="_blank" rel="noopener noreferrer" style={{ fontWeight: 'bold', fontSize: '1rem', color: '#3b82f6', textDecoration: 'none' }}>{v.title}</a>
                <p>📺 <strong>Channel:</strong> {v.channel}</p>
                <p>👁️ <strong>Views:</strong> {v.views.toLocaleString()}</p>
                <p>⏱️ <strong>Duration:</strong> {v.duration}</p>
                <p>👥 <strong>Subscribers:</strong> {v.subs.toLocaleString()}</p>
                <p>📅 <strong>Published:</strong> {new Date(v.published).toLocaleDateString()}</p>
              </div>
            </div>
          ))}
        </div>
      </section>
    </div>
  );
}

const inputStyle = {
  padding: '0.5rem',
  borderRadius: '5px',
  border: '1px solid #ccc',
  width: '100%',
  outline: 'none',
  fontSize: '0.9rem',
  background: '#fff',
  color: '#111'
};

const labelStyle = {
  display: 'block',
  marginBottom: '0.25rem',
  fontSize: '0.85rem',
  color: '#ccc'
};

const buttonStyle = {
  background: '#4f46e5',
  color: 'white',
  border: 'none',
  borderRadius: '5px',
  padding: '0.6rem 1.2rem',
  fontSize: '1rem',
  cursor: 'pointer',
  marginTop: '1rem'
};
